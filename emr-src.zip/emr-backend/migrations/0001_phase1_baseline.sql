-- 0001_phase1_baseline.sql
-- Phase 1 schema (წყარო: emr_phase1_schema.sql). გამოყენებულ migration-ს აღარ ვცვლით —
-- ნებისმიერი ცვლილება მხოლოდ ახალი ფაილით (0002_..., 0003_...).

-- =====================================================================
-- EMR / HIS Database Schema — Phase 1 (MVP)
-- Single-tenant version (ერთი კლინიკა = ერთი ცალკე ინსტალაცია/DB)
--   - tenant_id/RLS ველები არ გვჭირდება, რადგან თითოეულ კლინიკას
--     აქვს საკუთარი ცალკე database instance.
-- PostgreSQL 16
-- =====================================================================

-- ---------------------------------------------------------------------
-- 0. გაფართოებები
-- ---------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "citext";   -- case-insensitive ტექსტი (email, ძებნა)
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- fuzzy/მიახლოებითი ძებნა გვარზე


-- =====================================================================
-- MODULE: auth_org — მომხმარებლები, როლები, განყოფილებები, აუდიტი
-- =====================================================================

CREATE TABLE departments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(150) NOT NULL,
    code            VARCHAR(50) UNIQUE NOT NULL,   -- CARDIO, SURG, ER, ICU, REGISTRATION...
    type            VARCHAR(50) NOT NULL,          -- 'inpatient','outpatient','diagnostic','administrative'
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    personal_number     VARCHAR(11) UNIQUE NOT NULL,     -- პირადი ნომერი
    first_name          VARCHAR(100) NOT NULL,
    last_name           VARCHAR(100) NOT NULL,
    email               CITEXT UNIQUE NOT NULL,
    phone               VARCHAR(50),
    password_hash       TEXT NOT NULL,
    department_id       UUID REFERENCES departments(id),
    license_number      VARCHAR(50),                      -- ექიმის სახელმწიფო სერტიფიკატის #
    specialty           VARCHAR(100),                     -- მაგ: "კარდიოლოგი"
    role                VARCHAR(50) NOT NULL,             -- 'admin','doctor','nurse','receptionist','billing','pharmacist'
    signature_file_path TEXT,                              -- ხელმოწერის/შტამპის სურათი (MinIO გზა) — ფაზა 1: image-based
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_users_department ON users(department_id);
CREATE INDEX idx_users_role ON users(role);

-- უცვლელი აუდიტ-ჟურნალი (საქართველოს პერსონალურ მონაცემთა კანონმდებლობა)
-- REVOKE UPDATE/DELETE ეს ცხრილი აპლიკაციის DB-როლისთვის — მხოლოდ INSERT.
CREATE TABLE audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    user_id         UUID REFERENCES users(id),
    action          VARCHAR(50) NOT NULL,       -- 'VIEW_PATIENT','UPDATE_DIAGNOSIS','DELETE_ORDER'...
    entity_name     VARCHAR(100) NOT NULL,      -- 'patients','encounter_diagnoses'...
    entity_id       VARCHAR(100) NOT NULL,
    old_data        JSONB,
    new_data        JSONB,
    ip_address      VARCHAR(45),
    user_agent      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_audit_user_entity ON audit_logs(user_id, entity_name, entity_id);
CREATE INDEX idx_audit_created_at ON audit_logs(created_at);


-- =====================================================================
-- MODULE: patients — MPI (Master Patient Index)
-- =====================================================================

CREATE TYPE gender_type AS ENUM ('male', 'female', 'other');

CREATE TABLE patients (
    id                          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    personal_number             VARCHAR(11) UNIQUE,      -- უცხოელზე შეიძლება იყოს NULL
    passport_number             VARCHAR(50),              -- უცხო ქვეყნის მოქალაქისთვის
    citizenship                 VARCHAR(3) NOT NULL DEFAULT 'GEO',
    first_name                  VARCHAR(100) NOT NULL,
    last_name                   VARCHAR(100) NOT NULL,
    birth_date                  DATE NOT NULL,
    gender                      gender_type NOT NULL,
    blood_group                 VARCHAR(5),               -- 0(I)Rh+, A(II)Rh- და ა.შ.
    phone_number                VARCHAR(50) NOT NULL,
    emergency_contact_name      VARCHAR(150),
    emergency_contact_phone     VARCHAR(50),
    address                     TEXT,
    is_deceased                 BOOLEAN NOT NULL DEFAULT FALSE,
    death_datetime              TIMESTAMPTZ,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_patient_identity CHECK (personal_number IS NOT NULL OR passport_number IS NOT NULL)
);

-- ძებნა: პირადი ნომერი, გვარი, ტელეფონი (Module 1 მოთხოვნა)
CREATE INDEX idx_patients_search ON patients(personal_number, last_name, phone_number);
CREATE INDEX idx_patients_name_trgm ON patients USING gin (last_name gin_trgm_ops); -- საჭიროებს pg_trgm გაფართოებას, თუ fuzzy search გინდა

-- ალერგიები (Critical Alerts ბლოკი)
CREATE TABLE patient_allergies (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    substance       VARCHAR(150) NOT NULL,          -- "პენიცილინი"
    reaction_type   VARCHAR(100),                    -- "ანაფილაქსია", "გამონაყარი"
    severity        VARCHAR(50) NOT NULL DEFAULT 'severe', -- 'mild','moderate','severe'
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    recorded_by     UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_allergies_patient ON patient_allergies(patient_id) WHERE is_active = TRUE;

-- ქრონიკული დაავადებები / რისკ-ფაქტორები (Critical Alerts ბლოკის მეორე ნაწილი)
CREATE TABLE patient_chronic_conditions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id      UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    icd10_code      VARCHAR(10),
    condition_name  VARCHAR(255) NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    recorded_by     UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_chronic_patient ON patient_chronic_conditions(patient_id) WHERE is_active = TRUE;


-- =====================================================================
-- MODULE: clinical — ვიზიტები (Encounters), ვიტალები, დიაგნოზები
-- =====================================================================

CREATE TYPE encounter_type AS ENUM ('outpatient', 'inpatient', 'emergency');
CREATE TYPE encounter_status AS ENUM ('planned', 'active', 'discharged', 'cancelled');

-- ვიზიტი — ყველა კლინიკური მოქმედების ქოლგა
CREATE TABLE encounters (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id              UUID NOT NULL REFERENCES patients(id),
    attending_doctor_id     UUID REFERENCES users(id),
    department_id           UUID NOT NULL REFERENCES departments(id),
    type                    encounter_type NOT NULL,
    status                  encounter_status NOT NULL DEFAULT 'active',
    start_time              TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    end_time                TIMESTAMPTZ,
    chief_complaint         TEXT,          -- ჩივილები
    history_of_present_illness TEXT,       -- ანამნეზი
    objective_status        TEXT,          -- ობიექტური სტატუსი
    created_at              TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_encounter_patient ON encounters(patient_id, status);
CREATE INDEX idx_encounter_doctor_date ON encounters(attending_doctor_id, start_time);

-- სასიცოცხლო პარამეტრები
CREATE TABLE encounter_vitals (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    encounter_id        UUID NOT NULL REFERENCES encounters(id) ON DELETE CASCADE,
    systolic_bp         INT,
    diastolic_bp        INT,
    heart_rate          INT,
    respiratory_rate    INT,
    temperature         NUMERIC(4,1),
    spo2                INT,
    weight_kg           NUMERIC(5,2),
    height_cm           NUMERIC(5,1),
    bmi                 NUMERIC(4,1) GENERATED ALWAYS AS (
                            CASE WHEN height_cm IS NOT NULL AND height_cm > 0
                                 THEN weight_kg / ((height_cm/100.0) * (height_cm/100.0))
                                 ELSE NULL END
                        ) STORED,
    taken_by            UUID REFERENCES users(id),
    recorded_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_vitals_encounter ON encounter_vitals(encounter_id, recorded_at);

-- დიაგნოზები (ICD-10)
CREATE TABLE encounter_diagnoses (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    encounter_id    UUID NOT NULL REFERENCES encounters(id) ON DELETE CASCADE,
    icd10_code      VARCHAR(10) NOT NULL,
    icd10_title     TEXT NOT NULL,
    diagnosis_type  VARCHAR(50) NOT NULL,     -- 'primary','secondary','admission'
    comment         TEXT,
    diagnosed_by    UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_diagnoses_encounter ON encounter_diagnoses(encounter_id);
CREATE INDEX idx_diagnoses_icd10 ON encounter_diagnoses(icd10_code);


-- =====================================================================
-- MODULE: outpatient — ამბულატორიის ორდერები (ფაზა 1 ფარგლები)
-- =====================================================================

-- ვიზიტების კალენდარი / ჩაწერა
CREATE TYPE appointment_status AS ENUM ('scheduled', 'confirmed', 'checked_in', 'completed', 'cancelled', 'no_show');

CREATE TABLE appointments (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id          UUID NOT NULL REFERENCES patients(id),
    doctor_id           UUID NOT NULL REFERENCES users(id),
    department_id       UUID NOT NULL REFERENCES departments(id),
    scheduled_start     TIMESTAMPTZ NOT NULL,
    scheduled_end       TIMESTAMPTZ NOT NULL,
    status              appointment_status NOT NULL DEFAULT 'scheduled',
    reason              TEXT,
    encounter_id        UUID REFERENCES encounters(id),   -- checked_in-ის შემდეგ ივსება
    created_by          UUID REFERENCES users(id),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_appointment_time CHECK (scheduled_end > scheduled_start)
);
CREATE INDEX idx_appointments_doctor_time ON appointments(doctor_id, scheduled_start);
CREATE INDEX idx_appointments_patient ON appointments(patient_id);

-- ელექტრონული დანიშნულება / რეცეპტი (ამბულატორია)
CREATE TABLE prescriptions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    encounter_id    UUID NOT NULL REFERENCES encounters(id),
    medication_name VARCHAR(255) NOT NULL,     -- ფაზა 1-ში სახარჯი catalog-ის გარეშე, პირდაპირ ტექსტი
    dosage          VARCHAR(100) NOT NULL,
    route           VARCHAR(50) NOT NULL,       -- 'oral','iv','im',...
    frequency       VARCHAR(50) NOT NULL,
    duration_days   INT,
    instructions    TEXT,
    prescribed_by   UUID NOT NULL REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_prescriptions_encounter ON prescriptions(encounter_id);

-- მიმართვები (კვლევაზე ან ჰოსპიტალიზაციაზე) — ჯერჯერობით generic ჩონჩხი,
-- imaging/DICOM-სპეციფიკური ველები (accession_number, study_instance_uid)
-- განზრახ არ ემატება ამ ეტაპზე — დაემატება მაშინ, როცა PACS ინტეგრაციაზე მივალთ.
CREATE TYPE referral_type AS ENUM ('lab', 'imaging', 'hospitalization', 'specialist_consult');
CREATE TYPE referral_status AS ENUM ('requested', 'in_progress', 'completed', 'cancelled');

CREATE TABLE referrals (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    encounter_id    UUID NOT NULL REFERENCES encounters(id),
    type            referral_type NOT NULL,
    target_department_id UUID REFERENCES departments(id),
    reason          TEXT NOT NULL,
    status          referral_status NOT NULL DEFAULT 'requested',
    result_text     TEXT,                        -- სადაც შედეგი/დასკვნა ჩაიწერება ხელით (ფაზა 1)
    requested_by    UUID NOT NULL REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at    TIMESTAMPTZ
);
CREATE INDEX idx_referrals_encounter ON referrals(encounter_id);
CREATE INDEX idx_referrals_status ON referrals(status);


-- =====================================================================
-- MODULE: forms — ქართული სამედიცინო ფორმები (№IV-100/ა)
-- =====================================================================

CREATE TABLE generated_documents (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    encounter_id        UUID NOT NULL REFERENCES encounters(id),
    document_type       VARCHAR(50) NOT NULL,       -- 'form_100', 'informed_consent', ...
    file_path           TEXT NOT NULL,               -- MinIO/S3 გზა
    verification_token  UUID NOT NULL DEFAULT uuid_generate_v4(), -- QR კოდში იშიფრება (verification URL-ის ნაწილი)
    generated_by        UUID REFERENCES users(id),
    generated_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT uq_document_verification_token UNIQUE (verification_token)
);
CREATE INDEX idx_documents_encounter ON generated_documents(encounter_id, document_type);
CREATE INDEX idx_documents_verification_token ON generated_documents(verification_token);


-- =====================================================================
-- MODULE: billing (მინიმალური, ფაზა 1) — ტარიფები, ინვოისი, სალარო
-- =====================================================================

CREATE TABLE service_tariffs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code        VARCHAR(50) UNIQUE NOT NULL,
    title       TEXT NOT NULL,
    base_price  NUMERIC(10,2) NOT NULL,
    is_active   BOOLEAN NOT NULL DEFAULT TRUE
);

-- referral.type → default ტარიფის მაპინგი (ავტომატური მიბმისთვის)
CREATE TABLE referral_type_tariffs (
    type        referral_type PRIMARY KEY,
    tariff_id   UUID NOT NULL REFERENCES service_tariffs(id)
);

CREATE TABLE invoices (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    encounter_id    UUID NOT NULL REFERENCES encounters(id),
    invoice_number  VARCHAR(50) UNIQUE NOT NULL,
    total_amount    NUMERIC(10,2) NOT NULL,
    patient_share   NUMERIC(10,2) NOT NULL,
    insurance_share NUMERIC(10,2) NOT NULL DEFAULT 0,
    state_share     NUMERIC(10,2) NOT NULL DEFAULT 0,
    paid_status     VARCHAR(50) NOT NULL DEFAULT 'unpaid', -- 'unpaid','partially_paid','paid'
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_invoices_encounter ON invoices(encounter_id);

CREATE TABLE invoice_line_items (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id      UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    tariff_id       UUID REFERENCES service_tariffs(id),
    description     TEXT NOT NULL,
    quantity        INT NOT NULL DEFAULT 1,
    unit_price      NUMERIC(10,2) NOT NULL,          -- ფაქტობრივი ფასი (შეიძლება ტარიფისგან განსხვავებული)
    original_price  NUMERIC(10,2),                   -- ტარიფის ფასი შექმნის მომენტში (შედარებისთვის)
    discount_reason TEXT,                            -- სავალდებულო, თუ unit_price < original_price
    adjusted_by     UUID REFERENCES users(id),        -- ვინ შეასწორა ფასი
    line_total      NUMERIC(10,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,

    CONSTRAINT chk_discount_reason CHECK (
        original_price IS NULL
        OR unit_price >= original_price
        OR discount_reason IS NOT NULL
    )
);
CREATE INDEX idx_invoice_lines_invoice ON invoice_line_items(invoice_id);

CREATE TABLE payments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id      UUID NOT NULL REFERENCES invoices(id),
    amount          NUMERIC(10,2) NOT NULL,
    method          VARCHAR(50) NOT NULL,       -- 'cash','card_terminal','bank_transfer'
    terminal_ref    VARCHAR(100),               -- საბანკო ტერმინალის ტრანზაქციის ID (BOG/TBC)
    received_by     UUID REFERENCES users(id),
    paid_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_payments_invoice ON payments(invoice_id);

-- გადაუხდელობის შემთხვევაში encounter-ის მაინც აქტიურ სტატუსში გადაყვანის
-- ნებართვა (per-encounter override, არა გლობალური switch).
-- ბიზნეს-წესი (აპლიკაციის დონეზე): encounter 'planned' → 'active' დაშვებულია
-- მხოლოდ თუ ან (ა) დაკავშირებული invoice.paid_status IN ('paid','partially_paid'),
-- ან (ბ) ამ ცხრილში არსებობს ჩანაწერი ამ encounter_id-ზე.
CREATE TABLE encounter_payment_overrides (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    encounter_id    UUID UNIQUE NOT NULL REFERENCES encounters(id),
    reason          TEXT NOT NULL,                -- სავალდებულო დასაბუთება
    approved_by     UUID NOT NULL REFERENCES users(id), -- RBAC-ით შემოწმდება უფლებამოსილება (მაგ. 'admin','doctor')
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_payment_overrides_approver ON encounter_payment_overrides(approved_by);


-- =====================================================================
-- შენიშვნები / დიზაინის გადაწყვეტილებები
-- =====================================================================
-- 1. tenant_id/RLS მიზანმიმართულად არ არის დამატებული — თითოეული კლინიკა
--    იღებს საკუთარ, დამოუკიდებელ DB instance-ს.
-- 2. imaging/DICOM ველები (accession_number, study_instance_uid, pacs_url)
--    "referrals" ცხრილს დაემატება ცალკე migration-ით, როცა PACS ინტეგრაციაზე
--    გადავალთ — ეს დაცავს ამ schema-ს "clean"-ს ამ ეტაპისთვის.
-- 3. medication_orders/MAR (ინპაციენტის დანიშნულების ფურცელი) და
--    inpatient_beds, surgery_er, pharmacy_inventory, drg_records — ფაზა 2/3-ის
--    ცხრილებია და განზრახ არ არის ამ ფაილში, რომ Phase 1 scope გასუფთავებული დარჩეს.
-- 4. audit_logs-ზე აპლიკაციის DB user-ს უნდა ჰქონდეს მხოლოდ INSERT უფლება
--    (REVOKE UPDATE, DELETE ON audit_logs FROM app_role;) — ეს უზრუნველყოფს
--    "უცვლელი ლოგის" კანონმდებლობის მოთხოვნას აპლიკაციის დონეზე მაინც.
-- 5. invoices.insurance_share ივსება ხელით (ფაზა 1-ში დაზღვევის კომპანიის
--    საგარანტიო წერილის დადასტურების ავტომატური workflow არ არის საჭირო).
-- 6. encounter_payment_overrides — უფლებამოსილ პერსონალს (RBAC role-ით)
--    შეუძლია კონკრეტული encounter-ისთვის გვერდის ავლა გადახდის მოთხოვნას,
--    სავალდებულო დასაბუთებით; ეს არ ცვლის ნაგულისხმევ "გადახდა-შემდეგ-ვიზიტი"
--    წესს, უბრალოდ per-case გამონაკლისის შესაძლებლობას იძლევა.
-- 7. users.signature_file_path — ფაზა 1: ხელმოწერა/შტამპი image-ად (PNG), არა
--    კრიპტოგრაფიული ხელმოწერა; მოგვიანებით schema-ს დაშლის გარეშე გადაისვლება.
-- 8. generated_documents.verification_token — QR კოდის საფუძველი (მაგ.
--    https://.../verify/<token>); სადაზღვევო კომპანია ამოწმებს დოკუმენტის
--    ავთენტურობას ტოკენით, თავად PDF ფაილის გავრცელების გარეშე.
-- 9. referral_type_tariffs — ავტომატური ტარიფის მიბმა referral.type-ის მიხედვით;
--    invoice_line_items.unit_price მაინც ხელით შესწორებადია (ფასდაკლება/ნულოვანი
--    ფასდათმობა), მაგრამ CHECK constraint-ი (chk_discount_reason) აიძულებს
--    დასაბუთებას (discount_reason), როცა ფასი original_price-ზე დაბალია —
--    ეს არის DB-დონის გარანტია, არა მხოლოდ აპლიკაციის ვალიდაცია.
-- =====================================================================

-- =====================================================================
-- აპლიკაციის runtime როლის (emr_app) უფლებები
-- (DEFAULT PRIVILEGES უკვე დაყენებულია DB init-ზე; აქ ცხადად ვადასტურებთ)
-- =====================================================================
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'emr_app') THEN
    GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO emr_app;
    GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO emr_app;
    -- უცვლელი აუდიტ-ლოგი: მხოლოდ INSERT/SELECT
    REVOKE UPDATE, DELETE, TRUNCATE ON audit_logs FROM emr_app;
  END IF;
END
$$;
